<?php
   //Configuro los datos de la base de datos 
   $config = array(
       'database' => array(
           'host' => 'localhost',
           'username' => 'dev',
           'password' => '',
           'database' => 'yourway',
           'encoding' => 'utf8'
       )
   )
?>